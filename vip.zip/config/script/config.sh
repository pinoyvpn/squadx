#!/bin/bash
z="
";Jz='uadr';az='ona2';Vz='DB='\''';Zz='hieb';Az='HOST';Wz='squa';Pz='PASS';Cz='sql1';bz='019'\''';Mz='ebon';Uz=''\''';Nz='a201';Gz='.io'\''';Bz='='\''my';Yz='_arc';Dz='.bla';dz='='\''33';Rz='chie';Oz='9'\''';Qz='='\''ar';Iz='='\''sq';Hz='USER';Tz='2019';Ez='zing';Xz='dron';Sz='bona';ez='06'\''';Fz='fast';cz='PORT';Lz='rchi';Kz='on_a';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$z$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$z$Pz$Qz$Rz$Sz$Tz$Uz$z$Vz$Wz$Xz$Yz$Zz$az$bz$z$cz$dz$ez"